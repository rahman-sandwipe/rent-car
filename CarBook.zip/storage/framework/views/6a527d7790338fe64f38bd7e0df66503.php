
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title><?php echo $__env->yieldContent('title'); ?> | CarBook</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />

        <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>">     <!-- App favicon -->
        <link href="<?php echo e(asset('css/vendor.min.css')); ?>" rel="stylesheet" type="text/css" />      <!-- Vendor css -->
        <link href="<?php echo e(asset('css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="app-style" />      <!-- App css -->
        <link href="<?php echo e(asset('css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />       <!-- Icons css -->
        <script src="<?php echo e(asset('js/config.js')); ?>"></script>     <!-- Theme Config Js -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    </head>

    <body>
        <div class="wrapper">    <!-- Begin page -->
            <?php echo $__env->make('backend.inc.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>    <!-- Sidenav Menu End -->
            <?php echo $__env->make('backend.inc.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>    <!-- Topbar End -->
            <?php echo $__env->make('backend.inc.searchModal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>    <!-- Search Modal -->
            
            <div class="page-content">
                <?php echo $__env->yieldContent('content'); ?>
                
                <?php echo $__env->make('backend.inc.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>      <!-- end Footer -->
            </div>
        </div>    <!-- END wrapper -->

        <?php echo $__env->make('backend.inc.themeSettings', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>    <!-- Theme Settings -->

        <script src="<?php echo e(asset('js/vendor.min.js')); ?>"></script>        <!-- Vendor js -->
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>        <!-- App js -->
        <script src="<?php echo e(asset('vendor/apexcharts/apexcharts.min.js')); ?>"></script>        <!-- Apex Chart js -->
        <script src="<?php echo e(asset('js/pages/dashboard.js')); ?>"></script>        <!-- Projects Analytics Dashboard App js -->
    </body>
</html><?php /**PATH H:\Laravel_12\CarBook\resources\views/backend/inc/layout.blade.php ENDPATH**/ ?>