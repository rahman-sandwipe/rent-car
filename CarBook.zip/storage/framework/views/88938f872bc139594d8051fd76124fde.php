<footer class="footer">
    <div class="page-container">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <script>
                    document.write(new Date().getFullYear())
                </script> © <?php echo e(config('app.name')); ?> - By <span
                    class="fw-bold text-decoration-underline text-uppercase text-reset fs-12">Coderthemes</span>
            </div>
            <div class="col-md-6">
                <div class="text-md-end footer-links d-none d-md-block">
                    <a href="javascript: void(0);">About</a>
                    <a href="javascript: void(0);">Support</a>
                    <a href="javascript: void(0);">Contact Us</a>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH H:\Laravel_12\CarBook\resources\views/backend/inc/footer.blade.php ENDPATH**/ ?>