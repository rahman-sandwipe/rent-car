<link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('css/open-iconic-bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/ionicons.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-datepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.timepicker.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('css/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/icomoon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<?php /**PATH H:\Laravel_12\CarBook\resources\views/frontend/inc/styles.blade.php ENDPATH**/ ?>