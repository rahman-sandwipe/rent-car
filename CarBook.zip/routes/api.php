<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\Backend\CustomerController;




/** API Routes */
Route::middleware('api')->group(function () {
    Route::post('/register',            [AuthController::class, 'registerPost']);
    Route::post('/login',               [AuthController::class, 'loginPost']);
    Route::post('/password/recovery',   [AuthController::class, 'passwordRecoveryPost']);
	Route::get('/customerList',         [CustomerController::class, 'customerList']);
    Route::get('/adminList',            [CustomerController::class, 'adminList']);
});